import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-recipe-start',
  templateUrl: './invoice-start.component.html',
  styleUrls: ['./invoice-start.component.css']
})
export class InvoiceStartComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
